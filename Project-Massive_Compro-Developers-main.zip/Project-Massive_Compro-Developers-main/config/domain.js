const {portNumber} = require('./port')

const domain = `localhost:${portNumber}` 

module.exports = { domain }