const portNumber = 4000

module.exports = { portNumber }