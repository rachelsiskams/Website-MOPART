const secretKey = 'mopartauth'

module.exports = {secretKey}