export const navLinks = [
  {
    id: 1,
    path: '/',
    text: 'Beranda',
  },
  {
    id: 2,
    path: '/tentang-kami',
    text: 'Tentang Kami',
  },
  {
    id: 3,
    path: '/pameran',
    text: 'Pameran',
  },
  {
    id: 4,
    path: '/galeri',
    text: 'Galeri',
  },
  {
    id: 5,
    path: '/seniman',
    text: 'Seniman',
  },
];
