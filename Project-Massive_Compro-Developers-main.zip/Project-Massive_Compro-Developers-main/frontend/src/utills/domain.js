

const domain = () => {
    const domain = `localhost:4000`
}

export default domain