cara menginstal library yang dibutuhkan 
- buka terminal di directori interface atau di Project-Massive_Compro-Developers
- ketik npm instal (untuk menginstal semua dependecy yang dibutuhkan untuk backend)
- ketik node server.js (untuk menjalankan server.js di directori interface)

yang harus diinstall untuk menjalankan react js
- buka folder Project-Massive-Compro-Developers
- buka terminal
- ketik "cd frontend" untuk membuka folder frontend
- npx create-react-app . (pakai "." agar langsung terinstall di foldernya)
- npm install react-bootstrap bootstrap (untuk menginstall react bootstrap)
- npm install react-router-dom (untuk menginstall react router)
- npm install react-slick --save (untuk menginstall react slick)
- npm install slick-carousel --save (untuk menginstall carousel dari react slick)
- npm install animate.css --save (untuk menginstall animate style css)
- npm install --save aos@next (untuk menginstall animate on scroll library)
- npm start (untuk menjalankan projeknya)

> dependency bisa check di file package.json
